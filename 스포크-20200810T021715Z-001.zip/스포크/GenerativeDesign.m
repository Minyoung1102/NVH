% c1: Lambda (0.0005 <= c1 <=5) 
% c2: LoadRatio (0 <= c2 <=0.4)
% c3: VolumeRatio (0.9 <= c3 <=1.1)
% N: reference #

% example: GenerativeDesign(0.05,0.2,0.9,1)
function results = GenerativeDesign(c1,c2,c3,N,pp)
c1=0.0005;
c2=0.4;
c3=0.15;
N=850;
pp=4;
%Conditions
Lambda=c1;
LoadRatio=c2;
VolRatio=c3;


%% Read reference design
ImgPath = [pwd,filesep]; %Reference Path
      
ImageName = ['Binary_',num2str(N),'.jpg'];
Image2D  = imread([ImgPath,filesep,ImageName]);
   
% Filter reference design    
    if size(Image2D,3)>1
        Filter_Image = -(mat2gray(rgb2gray(Image2D(:,:,1:3)))-1); % Relative density scale �� ��ȯ
    else
        Filter_Image = -(mat2gray(Image2D)-1); % Relative density scale �� ��ȯ
    end
    
    BW1 = Filter_Image;
    BW1(BW1>0.6) = 1;
    BW1(BW1<0.6) = 0;
    
%% Call ToplogyOptimization    
    xPhys=ToplogyOptimization(Lambda,LoadRatio,VolRatio,BW1,pp);
    
%% PostProcess
    xPhys(xPhys>0.6) = 1;
    xPhys(xPhys<0.6) = 0;

%Recalculate Compliance    
    y=Validate(Lambda,LoadRatio,VolRatio,xPhys);   
    Vol=mean(xPhys(:));
    
%Save optimal design    
    filename = [pwd,filesep,sprintf('��ũ(0.15)_%g_%g_%g_%g_%g',N,c1,c2,c3,pp)];
    imwrite(1-xPhys,[filename,'.jpg']);
    clf  
        
results=xPhys;

